#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"

#include "digital_keypad.h"
#include <xc.h>

void init_config(void)
{
    init_adc();
    init_digital_keypad();
    init_can();
}
int main(void)
{   
	init_config();

	while(1)
	{	
        get_rpm();
        process_indicator();
	}
}
