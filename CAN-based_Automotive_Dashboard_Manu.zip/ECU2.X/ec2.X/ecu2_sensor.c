#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
#include "digital_keypad.h"



#define _XTAL_FREQ 8000000
void display(char data[])
{
    for(int i=0;i<4;i++)
    {
        PORTD=data[i];
        PORTA=(PORTA & 0xf0)| (1<<i);
        for(int delay=500;delay--;);
    }
}
char ssd[4];

char status=0;
int rpm;
char digit[10]={0xE7,0x21,0xCB,0x6B,0x2D,0x6E,0xEE,0x23,0xEF,0x6F};
uint16_t get_rpm()
{
    rpm = ((unsigned long)read_adc(CHANNEL4) * 6000) / 1023;


    ssd[0] = (rpm/1000) + '0';
ssd[1] = ((rpm/100)%10) + '0';
ssd[2] = ((rpm/10)%10) + '0';
ssd[3] = (rpm%10) + '0';
   can_transmit(RPM_MSG_ID ,ssd,4);
   __delay_ms(80); 
    return rpm;
}

uint16_t get_engine_temp()
{
    //Implement the engine temperature function
}

IndicatorStatus process_indicator()
{
    unsigned key = read_digital_keypad(STATE_CHANGE);

    if(key == 0x0e)
    {
        status = 1;
       
        
       
    }
    else if(key == 0x0b)
    {
       
        status = 2;
        
       
    }
    else if(key == 0x0d)
    {
       
        status = 0;
        
    }
 
    
    
    
      can_transmit(INDICATOR_MSG_ID ,
              &status,1);  
      
       __delay_ms(80);
      
}