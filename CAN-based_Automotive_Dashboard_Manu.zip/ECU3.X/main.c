/*
 * Project Title  : CAN-Based Automotive Dashboard
 *
 * Start Date     : 28 March 2026
 * End Date       : 18 April 2026
 *
 * Author         : Manu H P
 *
 * Brief Summary:
 * This project implements a multi-node automotive dashboard using CAN protocol with three PIC18F4580-based ECUs communicating over the CAN bus.
 * 
 * ECUs 
 * -> ECU1 transmits vehicle Speed and Gear Position.
 * -> ECU2 transmits RPM and Indicator status.
 * -> ECU3 receives CAN messages, displays data on CLCD, and controls indicator blinking using Timer0 interrupt.
 *
 * The project demonstrates distributed ECU communication, CAN message handling, and real-time automotive dashboard functionality.
 */
#include <xc.h>
#include <stdint.h>
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "message_handler.h"
#include "timer0.h"

static void init_leds() {
    TRISB = 0x08; // Set RB2 as output, RB3 as input, remaining as output
    PORTB = 0x00;
}

static void init_config(void) 
{
    // Initialize CLCD and CANBUS
    init_clcd();
    init_can();
    init_leds();
    // Enable Interrupts
    PEIE = 1;
    GIE = 1;
    init_timer0();
}

void main(void) 
{
    // Initialize peripherals
    init_config();

    /* ECU1 main loop */
    while (1) 
    {
        // Read CAN Bus data and handle it
        process_canbus_data();
    }

    return;
}
