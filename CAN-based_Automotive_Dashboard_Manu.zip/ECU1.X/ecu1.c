#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
#include "uart.h"

int main() 
{
    init_matrix_keypad();
    init_adc();
    init_can();
    while (1) 
    {
        get_speed();
        get_gear_pos();
    }
}